import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { AlertController, NavController, Platform } from '@ionic/angular';
import { NRect } from '../interfaces/nrect';
import { BACKGROUND_COLOR, BOAT_COLOR, BOAT_OVERLAP_COLOR, BOAT_SELECTED_COLOR, BOAT_SELECTED_LINE_WIDTH, CELL_NUMBER, GRID_COLOR } from 'src/environments/environment';



@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage implements AfterViewInit {
  @ViewChild('imageCanvas', { static: false }) canvas: any;
  canvasElement: any;
  size: number = 0;
  cellSize: number = 0;
  nickname: string = '';
  remoteServer: string = '';
  private ctx: CanvasRenderingContext2D | undefined;


  private deployment: NRect[] = [
    { x: 0, y: 0, w: 1, h: 1 },
    { x: 3, y: 0, w: 1, h: 2 },
    { x: 7, y: 0, w: 1, h: 1 },
    { x: 1, y: 3, w: 1, h: 1 },
    { x: 5, y: 3, w: 2, h: 1 },
    { x: 8, y: 3, w: 1, h: 2 },
    { x: 0, y: 5, w: 1, h: 1 },
    { x: 2, y: 5, w: 4, h: 1 },
    { x: 8, y: 6, w: 1, h: 3 },
    { x: 3, y: 8, w: 3, h: 1 },
  ];

  constructor(private alertController: AlertController,
    private navCtrl: NavController) { }

  ngAfterViewInit(): void {
    this.canvasElement = this.canvas.nativeElement;
    let size = this.canvasElement.width;
    if (this.canvasElement.height < size) size = this.canvasElement.height;
    let gridSpace = CELL_NUMBER - 1;
    let cellSize = Math.floor((size - gridSpace) / CELL_NUMBER);
    size = cellSize * CELL_NUMBER + gridSpace;
    this.canvasElement.width = size;
    this.canvasElement.height = size;
    console.log('canvasElement:', this.canvasElement.width, this.canvasElement.height);
    this.size = size;
    this.cellSize = cellSize;
    console.log('cellSize:', cellSize);
    this.ctx = this.canvasElement.getContext('2d');
    this.paint(this.ctx!);
    console.log('ngAfterViewInit: end');
  }
  drawBoat(ctx: CanvasRenderingContext2D, boat: NRect, selected: boolean, overlap: boolean) {
    
    let xr = boat.x * (this.cellSize + 1) + 1;
    let yr = boat.y * (this.cellSize + 1) + 1;
    let wr = boat.w * (this.cellSize + 1) - 2;
    let hr = boat.h * (this.cellSize + 1) - 2;

    ctx.fillStyle = overlap ? BOAT_OVERLAP_COLOR : BOAT_COLOR;
    ctx.fillRect(xr, yr, wr, hr);
    if (selected) {
      ctx.strokeStyle = BOAT_SELECTED_COLOR;
      ctx.lineWidth = BOAT_SELECTED_LINE_WIDTH;
      ctx.strokeRect(xr, yr, wr, hr);
    }
  }
  drawBoats(ctx: CanvasRenderingContext2D, boats: NRect[]) {
    let ovls = this.calculateOverlaps(boats);
    for (let i = 0; i < boats.length; i++) {
      let boat: NRect = boats[i];
      if (i != this.iCurrentBoat)
        this.drawBoat(ctx, boat, false, ovls[i]);
    }
    if (this.iCurrentBoat >= 0)
      this.drawBoat(ctx, boats[this.iCurrentBoat],true, ovls[this.iCurrentBoat]);
  }

  private calculateOverlaps(boats: NRect[]): boolean[] {
    if (boats.length <= 0) return [];
    let ovls: boolean[] = [];
    for (let i = 0; i < boats.length; i++) ovls.push(false);
    let m: number[][] = [];
    for (let i = 0; i < CELL_NUMBER; i++) {
      let line: number[] = [];
      for (let j = 0; j < CELL_NUMBER; j++) line.push(-1);
      m[i] = line;
    }
    for (let ib = 0; ib < boats.length; ib++) {
      let boat = boats[ib];
      // check horizontal borders
      if (boat.x + boat.w - 1 >= CELL_NUMBER || boat.y + boat.h - 1 >= CELL_NUMBER) {
        ovls[ib] = true;
      }
      // draw boat in matrix m
      for (let ym = boat.y; ym < boat.y + boat.h; ym++) {
        for (let xm = boat.x; xm < boat.x + boat.w; xm++) {
          if (xm < 0 || xm >= CELL_NUMBER) continue;
          if (ym < 0 || ym >= CELL_NUMBER) continue;
          if (m[ym][xm] != -1) {
            ovls[m[ym][xm]] = true;
            ovls[ib] = true;
          }
          m[ym][xm] = ib;
        }
      }
    }
    // console.log('ovls: ',ovls);
    return ovls;
  }

  paint(ctx: CanvasRenderingContext2D) {
    // drawing background
    let gridSize = CELL_NUMBER - 1;
    let cellSize = Math.floor((this.size - gridSize) / CELL_NUMBER);
    ctx.fillStyle = BACKGROUND_COLOR;
    ctx.fillRect(0, 0, this.size, this.size);
    // drawing vertical grid
    ctx.strokeStyle = GRID_COLOR;
    ctx.lineWidth = 1;
    for (let i = 0; i <= CELL_NUMBER; i++) {
      ctx.beginPath();
      ctx.moveTo(i * (cellSize + 1), 0);
      ctx.lineTo(i * (cellSize + 1), this.size);
      ctx.strokeStyle = '1px';
      ctx.stroke();
    }
    // drawing horizontal grid
    for (let i = 0; i <= CELL_NUMBER; i++) {
      ctx.beginPath();
      ctx.moveTo(0, i * (cellSize + 1));
      ctx.lineTo(this.size, i * (cellSize + 1));
      ctx.stroke();
    }
    // draw boats
    this.drawBoats(ctx, this.deployment);
  }

  findBoat(xp: number, yp: number, boats: NRect[]): number {
    // console.log('findBoat, xp:',xp,', yp: ',yp,'cellSize: ',this.cellSize);
    for (let ib = 0; ib < boats.length; ib++) {
      let boat = boats[ib];
      let x1 = boat.x * (this.cellSize + 1) + 1;
      let wr = boat.w * (this.cellSize + 1) - 1;
      let x2 = x1 + wr;
      // console.log('findBoat: x1:',x1,' x2:',x2);
      if (x1 < xp && xp < x2) {
        let y1 = boat.y * (this.cellSize + 1) + 1;
        let hr = boat.h * (this.cellSize + 1) - 1;
        let y2 = y1 + hr;
        // console.log('findBoat: y1:',y1,'y2:',y2);
        if (y1 < yp && yp < y2) {
          // console.log('findBoat: found',ib);
          return ib;
        }
      }
    }
    return -1;
  }
  private pointPressDiff = { dx: 0, dy: 0 };
  private iCurrentBoat: number = -1;

  clicked(ev: MouseEvent) {
    let xp = ev.offsetX;
    let yp = ev.offsetY;
    if (this.iCurrentBoat < 0) {
      this.iCurrentBoat = this.findBoat(xp, yp, this.deployment);
      if (this.iCurrentBoat < 0) return;  // selected empty water
      let boat = this.deployment[this.iCurrentBoat];
      let x1 = boat.x * (this.cellSize + 1) + 1;
      let y1 = boat.y * (this.cellSize + 1) + 1;
      this.pointPressDiff.dx = x1 - xp;
      this.pointPressDiff.dy = y1 - yp;
      this.paint(this.ctx!);
      return;
    }
    // there is a boat selected
    let boat = this.deployment[this.iCurrentBoat];
    let x1 = xp + this.pointPressDiff.dx;
    let y1 = yp + this.pointPressDiff.dy;
    let x = Math.round(x1 / (this.cellSize + 1));
    let y = Math.round(y1 / (this.cellSize + 1));
    if (x < 0) {
      x = 0;
    } else if (x >= CELL_NUMBER) {
      x = CELL_NUMBER - 1;
    }
    if (y < 0) {
      y = 0;
    } else if (y >= CELL_NUMBER) {
      y = CELL_NUMBER - 1;
    }
    if (boat.x !== x || boat.y !== y) { // boat moved to another place
      boat.x = x;
      boat.y = y;
    } else { // rotate boat
      let aux = boat.w;
      boat.w = boat.h;
      boat.h = aux;
    }

    this.iCurrentBoat = -1;
    this.paint(this.ctx!);
  }

  async connect() {
    console.log('connect:');
    let errors: string[] = [];
    this.nickname = this.nickname.trim();
    if (this.nickname.length <=0) {
      errors.push('nickname requerido');
    }
    this.remoteServer = this.remoteServer.trim();
    if (this.remoteServer.length <= 0) {
      errors.push('server requerido');
    }
    if (this.calculateOverlaps(this.deployment).some(v=>v)) {
      errors.push('hay solapamento de naves');
    }
    if (errors.length > 0) {
      const alert = await this.alertController.create({
        header: 'Fallos',
        subHeader: '',
        message: errors.join(', '),
        buttons: ['Volver'],
      });
      await alert.present();
    } else {
      console.log('trying to connect to server');
      this.navCtrl.navigateForward('/play');
    }
  }
}
