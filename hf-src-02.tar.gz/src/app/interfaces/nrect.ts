export interface NRect {
    x:number,
    y:number,
    w:number,
    h:number,
}
