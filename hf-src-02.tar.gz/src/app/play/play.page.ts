import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { BACKGROUND_COLOR, CELL_NUMBER, GRID_COLOR } from 'src/environments/environment';

@Component({
  selector: 'app-play',
  templateUrl: './play.page.html',
  styleUrls: ['./play.page.scss'],
})
export class PlayPage implements OnInit, AfterViewInit {
  @ViewChild('opponentCanvas', { static: false }) oCanvas: any;
  @ViewChild('myCanvas', { static: false }) mCanvas: any;
  oCanvasElement: any;
  mCanvasElement: any;
  size: number = 0;
  cellSize: number = 0;
  private octx: CanvasRenderingContext2D | undefined;
  private mctx: CanvasRenderingContext2D | undefined;





  constructor() { }

  ngOnInit() {
  }
  ngAfterViewInit(): void {
    this.oCanvasElement = this.oCanvas.nativeElement;
    this.mCanvasElement = this.mCanvas.nativeElement;

    let size = this.oCanvasElement.width;
    if (this.oCanvasElement.height < size) size = this.oCanvasElement.height;
    let gridSpace = CELL_NUMBER - 1;
    let cellSize = Math.floor((size - gridSpace) / CELL_NUMBER);
    size = cellSize * CELL_NUMBER + gridSpace;
    this.oCanvasElement.width = size;
    this.oCanvasElement.height = size;
    this.mCanvasElement.width = size;
    this.mCanvasElement.height = size;
    this.size = size;
    this.cellSize = cellSize;
    console.log('cellSize:', cellSize);
    this.octx = this.oCanvasElement.getContext('2d');
    this.mctx = this.mCanvasElement.getContext('2d');
    this.paint(this.octx!, this.mctx!);
  }

  drawBackground(ctx: CanvasRenderingContext2D) {
    let gridSize = CELL_NUMBER - 1;
    let cellSize = Math.floor((this.size - gridSize) / CELL_NUMBER);
    ctx.fillStyle = BACKGROUND_COLOR;
    ctx.fillRect(0, 0, this.size, this.size);
    // drawing vertical grid
    ctx.strokeStyle = GRID_COLOR;
    ctx.lineWidth = 1;
    for (let i = 0; i <= CELL_NUMBER; i++) {
      ctx.beginPath();
      ctx.moveTo(i * (cellSize + 1), 0);
      ctx.lineTo(i * (cellSize + 1), this.size);
      ctx.strokeStyle = '1px';
      ctx.stroke();
    }
    // drawing horizontal grid
    for (let i = 0; i <= CELL_NUMBER; i++) {
      ctx.beginPath();
      ctx.moveTo(0, i * (cellSize + 1));
      ctx.lineTo(this.size, i * (cellSize + 1));
      ctx.stroke();
    }
  }

  paint(octx: CanvasRenderingContext2D, mctx: CanvasRenderingContext2D) {
    this.drawBackground(octx);
    this.drawBackground(mctx);
  }
  fireOpponent($event: MouseEvent) {
    throw new Error('Method not implemented.');
  }
}
